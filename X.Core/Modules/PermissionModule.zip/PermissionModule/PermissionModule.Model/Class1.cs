﻿using System;

namespace PermissionModule.Model
{
    public class Class1
    {
    }
}
