﻿using System;

namespace PermissionModule.All
{
    public class Class1
    {
    }
}
